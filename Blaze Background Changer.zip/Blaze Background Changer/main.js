var quotes = ["\"Pika Pika Pika\nPi Pika Pi!\"\n- Pikachu",
 "\"Be yourself;\nEveryone else is already taken\"\n- Oscar Wilde",
 "\"Team rocket blasting\noff at the speed of light\"\n- Team Rocket James",
 "\"Me, give up?\nNo way!\"\n- Ash Ketchum",
 "\"That which does not kill us,\nmakes us stronger\"\n- Friedrich Nietzsche",
 "\"If opportunity doesn't knock,\nbuild a door\"\n- Milton Berle",
 "\"You miss 100%\nof the shots you don't take\"\n- Wayne Gretzky",
 "\"Why join the navy,\nwhen you can be a pirate?\"\n- Steve Jobs",
 "\"Always keep your face towards the sunshine,\nand the shadows will fall behind you\"\n- Walt Whitman",
 "\"You'll never find rainbows\nif you are looking down\"\n- Charlie Chaplin",
 "\"Sting like a butterfly,\nfloat like a bee\"\n- Muhammad Ali",
 "\"In the middle of chaos\nlies opportunity\"\n- Bruce Lee",
 "\"Only when it's dark enough,\nwill you see the stars\"\n- Martin Luther King Jr.",
 "\"Once we accept our limits,\nwe go beyond them\"\n- Albert Einstein",
 "\"It's not the size of the tiger in a fight,\nit's the size of fight in the tiger\"\n- Mark Twain",
 "\"If you can dream it,\nyou can do it\"\n- Walt Disney",
 "\"It always seems impossible\nuntil it's done\"\n- Nelson Mandela",
 "\"No bird soars too high\nif he soars with his own wings\"\n- William Blake",
 "\"Patience is bitter,\nbut it's fruit is sweet\"\n- Aristotle",
 "\"He who knows when to fight,\nand when he cannot,\nwill be victorious\"\n- Sun Tzu",
 "\"Our greatest glory is not in never falling,\nbut in rising everytime we fall\"\n- Confucious",
 "\"A day without laughter\nis a day wasted\"\n- Charlie Chaplin",
 "\"We don't laugh because we're happy,\nwe're happy because we laugh\"\n- William James",
 "\"Courage is knowing\nwhat not to fear\"\n- Plato",
 "\"History is written\nby the victors\"\n- Winston Churchill",
 "\"It's not in the stars to hold\nour destiny, but rather in ourselves\"\n- William Shakespeare"
 
];
var bg = ["0.jpg", "1.jpg", "2.jpg", "3.jpg", "4.jpg", "5.jpg", "6.jpg", "7.jpg", "8.jpg", "9.jpg", "10.jpg", "11.jpg", "12.png", "13.jpg", "14.jpg", "15.jpg", "16.jpg", "17.jpg", "18.jpg", "19.jpg"]


function setPageTitle(){
    let currentTimeDate = new Date();
    var weekday = new Array(7);
        weekday[0] = "Sun";
        weekday[1] = "Mon";
        weekday[2] = "Tue";
        weekday[3] = "Wed";
        weekday[4] = "Thu";
        weekday[5] = "Fri";
        weekday[6] = "Sat";
    var month = new Array();
        month[0] = "1";
        month[1] = "2";
        month[2] = "3";
        month[3] = "4";
        month[4] = "5";
        month[5] = "6";
        month[6] = "7";
        month[7] = "8";
        month[8] = "9";
        month[9] = "10";
        month[10] = "11";
        month[11] = "12";
    var currentDay = weekday[currentTimeDate.getDay()];
    var currentDate  = currentTimeDate.getDate();
    var currentMonth = month[currentTimeDate.getMonth()];
    var currentYear = currentTimeDate.getFullYear();
    currentMonth = currentMonth < 10 ? '0' + currentMonth : currentMonth;
    currentYear = currentYear < 10 ? '0' + currentYear : currentYear;
    document.title = currentDay + " " + currentDate + "/" + currentMonth + "/" + currentYear;
}

function setTime() {
    let dateTime = new Date();
    var hour = dateTime.getHours();
    var minute = dateTime.getMinutes();
    var ampm = "AM";
    hour = hour < 10 ? '0' + hour : hour;
    ampm = hour >= 12 ? 'pm' : 'am';
    hour = hour % 12;
    hour = hour ? hour : 12;
    minute = minute < 10 ? '0' + minute : minute;
    document.getElementById("clock").innerHTML = hour + ":" + minute + " " + ampm;
    setTimeout(setTime, 10000);
}

function chooseWallpaper() {
  var wallpaper = bg[Math.floor(Math.random() * bg.length)];
  document.body.style.backgroundImage = "url('images/" + wallpaper + "')";
}

function chooseQuote() {
  var quote = quotes[Math.floor(Math.random() * quotes.length)];
  document.getElementById('quote').innerText = quote;

}
setPageTitle();
setTime();
chooseWallpaper();
chooseQuote();